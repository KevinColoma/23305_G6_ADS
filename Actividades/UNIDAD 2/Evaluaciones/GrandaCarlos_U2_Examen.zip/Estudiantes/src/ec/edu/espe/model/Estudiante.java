package ec.edu.espe.model;

public class Estudiante {
    // Identificador único del estudiante
    private int id;
    // Apellidos del estudiante
    private String apellidos;
    // Nombres del estudiante
    private String nombres;
    // Edad del estudiante
    private int edad;

    /**
     * Constructor principal de Estudiante.
     * @param id Identificador único.
     * @param apellidos Apellidos completos.
     * @param nombres Nombres.
     * @param edad Edad en años.
     */
    public Estudiante(int id, String apellidos, String nombres, int edad) {
        this.id = id;                // Asigna el id al campo interno
        this.apellidos = apellidos;  // Asigna los apellidos al campo interno
        this.nombres = nombres;      // Asigna los nombres al campo interno
        this.edad = edad;            // Asigna la edad al campo interno
    }

    /** Devuelve el ID del estudiante. */
    public int getId() {
        return id;                   // Retorna el valor del campo id
    }

    /** Establece el ID del estudiante. */
    public void setId(int id) {
        this.id = id;                // Actualiza el campo id
    }

    /** Devuelve los apellidos del estudiante. */
    public String getApellidos() {
        return apellidos;            // Retorna el valor del campo apellidos
    }

    /** Establece los apellidos del estudiante. */
    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;  // Actualiza el campo apellidos
    }

    /** Devuelve los nombres del estudiante. */
    public String getNombres() {
        return nombres;              // Retorna el valor del campo nombres
    }

    /** Establece los nombres del estudiante. */
    public void setNombres(String nombres) {
        this.nombres = nombres;      // Actualiza el campo nombres
    }

    /** Devuelve la edad del estudiante. */
    public int getEdad() {
        return edad;                 // Retorna el valor del campo edad
    }

    /** Establece la edad del estudiante. */
    public void setEdad(int edad) {
        this.edad = edad;            // Actualiza el campo edad
    }

    /**
     * Representación en texto del estudiante.
     * @return Cadena con formato "id – apellidos nombres – Edad: edad".
     */
    @Override
    public String toString() {
        // Concatena los campos para mostrar información completa
        return id + " – " + apellidos + " " + nombres + " – Edad: " + edad;
    }
}
