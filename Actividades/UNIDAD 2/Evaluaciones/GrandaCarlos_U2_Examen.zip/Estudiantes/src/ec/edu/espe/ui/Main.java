package ec.edu.espe.ui;

import ec.edu.espe.controller.EstudianteController;
import ec.edu.espe.model.Estudiante;

import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        EstudianteController ctrl = new EstudianteController();
        Scanner sc = new Scanner(System.in);
        //crea la variable opcion
        int opcion;

        //se crea el menú
        do {
            // 1) Mostrar menú al usuario
            System.out.println("\n--- MENÚ ESTUDIANTES ---");
            System.out.println("1) Crear estudiante");
            System.out.println("2) Listar todos");
            System.out.println("3) Buscar por ID");
            System.out.println("4) Actualizar");
            System.out.println("5) Eliminar");
            System.out.println("0) Salir");

            // 2) Leer opción validada del menú
            System.out.print("Elija una opción: ");
            opcion = leerEntero(sc, 0, 5);

            // 3) Procesar lo que el usuario ingreso como opción
            switch (opcion) {
                case 1 -> {
                    // Si escoge el Caso 1: Crear nuevo estudiante
                    System.out.println("\n-- CREAR ESTUDIANTE --");
                    System.out.print("ID: ");
                    int id = leerEntero(sc, 0, Integer.MAX_VALUE);
                    System.out.print("Apellido: ");
                    String apellidos = sc.nextLine();
                    System.out.print("Nombre: ");
                    String nombres = sc.nextLine();
                    System.out.print("Edad: ");
                    int edad = leerEntero(sc, 0, Integer.MAX_VALUE);
                    ctrl.crearEstudiante(id, apellidos, nombres, edad);
                    System.out.println(">> Estudiante creado.");
                }
                case 2 -> {
                    // Si escoge el Caso 2: Lista los estudiantes completos
                    System.out.println("\n-- LISTA DE ESTUDIANTES --");
                    List<Estudiante> lista = ctrl.obtenerTodos();
                    if (lista.isEmpty()) {
                        System.out.println(">> No hay estudiantes registrados.");
                    } else {
                        lista.forEach(System.out::println);
                    }
                }
                case 3 -> {
                    // Si escoge el Caso 3: Busca un estudiante por el id que ingrese el usuario
                    System.out.println("\n-- BUSCAR POR ID --");
                    System.out.print("ID a buscar: ");
                    int idb = leerEntero(sc, 0, Integer.MAX_VALUE);
                    Estudiante e = ctrl.buscarEstudiante(idb);
                    System.out.println(e != null ? e : ">> No se han encontrado datos con este ID.");
                }
                case 4 -> {
                    // Si escoge el Caso 4: Actualiza el usuario por el id que ingresa el usuario
                    System.out.println("\n-- ACTUALIZAR ESTUDIANTE --");
                    // Forzar ID existente
                    int ida;
                    do {
                        System.out.print("ID a actualizar: ");
                        ida = leerEntero(sc, 0, Integer.MAX_VALUE);
                        if (ctrl.buscarEstudiante(ida) == null) {
                            System.out.println(">> ID no existe. Por favor ingrese otro.");
                        }
                    } while (ctrl.buscarEstudiante(ida) == null);

                    System.out.print("Nuevos Apellidos: ");
                    String nap = sc.nextLine();
                    System.out.print("Nuevos Nombres: ");
                    String nn  = sc.nextLine();
                    System.out.print("Nueva Edad: ");
                    int nea     = leerEntero(sc, 0, Integer.MAX_VALUE);
                    boolean ok  = ctrl.actualizarEstudiante(ida, nap, nn, nea);
                    System.out.println(ok
                            ? ">> Actualizado correctamente."
                            : ">> Error al actualizar.");
                }
                case 5 -> {
                    // Si escoge el Caso 1: Elimina un estudiante por el id que ingreso el usuario
                    System.out.println("\n-- ELIMINAR ESTUDIANTE --");
                    System.out.print("ID a eliminar: ");
                    int ide = leerEntero(sc, 0, Integer.MAX_VALUE);
                    boolean del = ctrl.eliminarEstudiante(ide);
                    System.out.println(del
                            ? ">> Eliminado correctamente."
                            : ">> ID no existe, no se pudo eliminar.");
                }
                //si escoge 0 sale del programa
                case 0 -> System.out.println("Saliendo...");
            }
        } while (opcion != 0);

        sc.close();
    }

    /**
     * Lee de consola un número entero entre min y max (ambos inclusive).
     * Repite hasta que la entrada sea válida (solo dígitos y dentro del rango).
     */
    private static int leerEntero(Scanner sc, int min, int max) {
        int valor;
        while (true) {
            String linea = sc.nextLine().trim();
            // 1) Solo dígitos
            if (!linea.matches("\\d+")) {
                System.out.print("ERROR: Solo números. Porfa intente de nuevo: ");
                continue;
            }
            // 2) Parse y rango
            valor = Integer.parseInt(linea);
            if (valor < min || valor > max) {
                System.out.printf("ERROR: Solo ingrese un valor entre %d y %d: ", min, max);
                continue;
            }
            break;
        }
        return valor;
    }
}
