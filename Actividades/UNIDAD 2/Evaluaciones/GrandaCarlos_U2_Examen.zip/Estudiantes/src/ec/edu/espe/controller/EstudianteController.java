package ec.edu.espe.controller;

import ec.edu.espe.dao.EstudianteDAO;
import ec.edu.espe.model.Estudiante;
import java.util.List;

public class EstudianteController {
    // Se crea una instancia de EstudianteDAO para manejar las operaciones con los datos
    private EstudianteDAO dao = new EstudianteDAO();

    //Crea un nuevo estudiante utilizando el dao, con los parametros: id, apellidos, nombre, edad
    public void crearEstudiante(int id, String apellidos, String nombres, int edad) {
        dao.agregar(new Estudiante(id, apellidos, nombres, edad));
    }

    //obtiene todos los estudiantes registrados
    public List<Estudiante> obtenerTodos() {
        return dao.listar();
    }

    //busca un estudiante por su ID
    public Estudiante buscarEstudiante(int id) {
        return dao.buscarPorId(id);
    }

    //actualiza la informacion de un estudiante existente
    public boolean actualizarEstudiante(int id, String apellidos, String nombres, int edad) {
        Estudiante e = new Estudiante(id, apellidos, nombres, edad);
        return dao.actualizar(e);
    }

    //Elimina un estudiante por su ID.
    public boolean eliminarEstudiante(int id) {
        return dao.eliminar(id);
    }
}
