package ec.edu.espe.dao;

import java.util.ArrayList;
import java.util.List;
import ec.edu.espe.model.Estudiante;

/**
 * DAO en memoria para gestionar operaciones CRUD de Estudiante.
 */
public class EstudianteDAO {
    private List<Estudiante> estudiantes = new ArrayList<>();

    /**Agrega un estudiante**/
    public void agregar(Estudiante e) {
        estudiantes.add(e);
    }

    /**Lista estudiantes**/
    public List<Estudiante> listar() {
        return new ArrayList<>(estudiantes);
    }

    /**Busca estudiante por id**/
    public Estudiante buscarPorId(int id) {
        for (Estudiante e : estudiantes) {
            if (e.getId() == id) {
                return e;
            }
        }
        return null;
    }

    /**
     * Actualiza los datos de un estudiante existente.
     * @param e Objeto Estudiante con ID ya existente.
     * @return true si lo encontró y actualizó, false si no existe.
     */
    public boolean actualizar(Estudiante e) {
        for (int i = 0; i < estudiantes.size(); i++) {
            if (estudiantes.get(i).getId() == e.getId()) {
                estudiantes.set(i, e);
                return true;
            }
        }
        return false;
    }

    /**
     * Elimina un estudiante por su ID.
     */
    public boolean eliminar(int id) {
        return estudiantes.removeIf(e -> e.getId() == id);
    }
}
